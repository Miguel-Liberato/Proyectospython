print('Hola')
print("Hola Mundo")
