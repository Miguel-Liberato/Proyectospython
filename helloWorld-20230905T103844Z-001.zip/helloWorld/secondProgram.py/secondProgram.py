# Define the release and runtime integer variables below:
release_year = 1977
runtime = 1980

# Define the rating_out_of_10 float variable below: 
rating_out_of_10 = 6.8
print(type(runtime))
print(type(rating_out_of_10))