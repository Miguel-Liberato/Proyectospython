import time

cadena = 'Python'

for letra in cadena:
   if letra == 't':
      continue
   print(letra)
   time.sleep(1)
   
