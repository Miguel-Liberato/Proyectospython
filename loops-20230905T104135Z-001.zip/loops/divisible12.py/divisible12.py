for i in range(100, 301):
    if (i%12) != 0:
        continue
    print(i)