for i in range(1,6):
    while i <= 4:
        i += 1
        print(i)
    break    