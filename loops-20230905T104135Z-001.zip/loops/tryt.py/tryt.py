my_cool_variable = 7 + 8 == 11
print(my_cool_variable)